# YoutubeRedirect
A Firefox extension that automatically redirects youtube-video links to a youtube version with no cookies and no ads.
