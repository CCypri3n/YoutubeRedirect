# YoutubeRedirect
A Firefox extension that can switch between the youtube player and a cookie-free, ad-free version for a cleaner viewing experience.

## TODO
- Add option to auto-redirect (AJAX is causing issues).
- Implement tab history preservation during switches.

## Errors
